/* Supabase browser config. Publishable key only; never put a service-role key here. */
window.ABHINAV_SUPABASE = Object.freeze({
  url: "https://ifxiobzojhzofbnttlub.supabase.co",
  publishableKey: "sb_publishable_gdEKHzs4XxpzC8arEFc3-w_-9TaJSxd"
});
