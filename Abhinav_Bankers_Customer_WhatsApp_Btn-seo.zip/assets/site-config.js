/* Public site configuration — contains no passwords, API keys or private credentials. */
window.ABHINAV_SITE_CONFIG = Object.freeze({
  goldRate22k: 11000,
  interestRate: 132,
  rateDate: "04/09/2026",
  seasonOffer: ""
});
