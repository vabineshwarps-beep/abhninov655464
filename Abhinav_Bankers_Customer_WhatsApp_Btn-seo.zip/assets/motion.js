/**
 * Abhinav Bankers Capital — Live Motion Engine
 * Scroll reveals, header state, micro-interactions
 */
(function () {
  "use strict";

  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ----- Twemoji: ensure emoji shows on Windows/PC ----- */
  (function loadTwemoji() {
    var s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/@twemoji/api@latest/dist/twemoji.min.js";
    s.crossOrigin = "anonymous";
    s.onload = function () {
      if (window.twemoji) {
        twemoji.parse(document.body, {
          folder: "svg",
          ext: ".svg",
          base: "https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/",
          className: "twemoji"
        });
      }
    };
    document.head.appendChild(s);
  })();


  /* ----- Reveal fallback (desktop / slow JS) ----- */
  setTimeout(function () {
    document.querySelectorAll(".reveal, .reveal-left, .reveal-right, .reveal-scale").forEach(function (el) {
      if (!el.classList.contains("visible")) el.classList.add("visible");
    });
  }, 400);

  /* ----- Sticky header shadow on scroll ----- */
  const header = document.querySelector(".site-header");
  if (header) {
    const onScroll = () => {
      header.classList.toggle("scrolled", window.scrollY > 24);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ----- Desktop-only pinned five-item navigation ----- */
  const referenceNavContainer = document.querySelector(".reference-nav-container");
  if (referenceNavContainer) {
    const updateDesktopNav = () => {
      if (window.innerWidth >= 1181) {
        const pinAt = referenceNavContainer.getBoundingClientRect().top + window.scrollY;
        referenceNavContainer.classList.toggle("nav-pinned", window.scrollY >= pinAt);
      } else {
        referenceNavContainer.classList.remove("nav-pinned");
      }
    };
    updateDesktopNav();
    window.addEventListener("scroll", updateDesktopNav, { passive: true });
    window.addEventListener("resize", updateDesktopNav, { passive: true });
  }

  /* ----- Mobile nav ----- */
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-wrap");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", nav.classList.contains("open"));
    });
    nav.querySelectorAll("a").forEach((a) => {
      a.addEventListener("click", () => nav.classList.remove("open"));
    });
  }

  /* ----- Scroll Reveal (Intersection Observer) ----- */
  if (!reduced) {
    const reveals = document.querySelectorAll(
      ".reveal, .reveal-left, .reveal-right, .reveal-scale"
    );
    if (reveals.length && "IntersectionObserver" in window) {
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add("visible");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );
      reveals.forEach((el) => io.observe(el));
    } else {
      reveals.forEach((el) => el.classList.add("visible"));
    }
  } else {
    document
      .querySelectorAll(".reveal, .reveal-left, .reveal-right, .reveal-scale")
      .forEach((el) => el.classList.add("visible"));
  }


  /* ----- Public site rate display: read-only via Supabase REST ----- */
  const localConfig = window.ABHINAV_SITE_CONFIG || { goldRate22k: 11000, interestRate: 132, rateDate: "04/09/2026", seasonOffer: "" };
  function renderRate(cfg) {
    const gold = Number(cfg.goldRate22k), interest = Number(cfg.interestRate);
    const date = String(cfg.rateDate || "—");
    document.querySelectorAll("#rate-22k").forEach(el => el.textContent = Number.isFinite(gold) ? String(gold) : "—");
    document.querySelectorAll(".js-interest-rate").forEach(el => el.textContent = Number.isFinite(interest) ? String(interest) : "—");
    document.querySelectorAll(".js-rate-date").forEach(el => el.textContent = date);
    const season = String(cfg.seasonOffer || "").trim();
    const displayOffer = season || "சலுகை விவரங்களுக்கு தொடர்பு கொள்ளுங்கள்.";
    const bar = document.getElementById("offersBar"), card = document.getElementById("seasonOfferCard"), text = document.getElementById("seasonOfferText");
    if (text) text.textContent = displayOffer;
    if (card) card.style.display = "block";
    if (bar) bar.style.display = "block";
  }
  renderRate(localConfig);
  (async function loadLiveRate(){
    const sb = window.ABHINAV_SUPABASE; if (!sb) return;
    try {
      const r = await fetch(sb.url + "/rest/v1/site_settings?id=eq.1&select=gold_rate_22k,interest_rate,rate_date,season_offer", {method:"GET", cache:"no-store", headers:{apikey:sb.publishableKey, Accept:"application/json", "Cache-Control":"no-cache"}});
      if (!r.ok) return; const rows = await r.json(); if (!rows[0]) return;
      const x=rows[0]; const d=x.rate_date ? x.rate_date.split("-").reverse().join("/") : "—";
      renderRate({goldRate22k:x.gold_rate_22k, interestRate:x.interest_rate, rateDate:d, seasonOffer:x.season_offer});
    } catch (_) {}
  })();

  /* ----- Loan enquiry: user-controlled WhatsApp + email; no third-party form token ----- */
  const loanForm = document.getElementById("loanApplicationForm");
  if (loanForm) {
    const loanAccGroup = document.getElementById("loanAccountGroup");
    const loanAccInput = document.getElementById("loanAccountNumber");

    loanForm.querySelectorAll('input[name="13_Existing_Customer"]').forEach(function (radio) {
      radio.addEventListener("change", function () {
        const isYes = this.value === "ஆம்" || this.value === "Yes";
        if (loanAccGroup) loanAccGroup.style.display = isYes ? "block" : "none";
        if (loanAccInput) {
          loanAccInput.required = isYes;
          if (!isYes) loanAccInput.value = "";
        }
      });
    });

    const status = document.getElementById("formStatusMsg");
    const submitBtn = document.getElementById("formSubmitBtn");
    const WHATSAPP_NUMBER = "918489858873";

    function valueOf(formData, key) {
      return String(formData.get(key) || "").trim();
    }

    function buildEnquiry(formData) {
      const existing = valueOf(formData, "13_Existing_Customer") || "-";
      return [
        "🙏 *புதிய கடன் விசாரணை - Abhinav Bankers*",
        "",
        "👤 பெயர்: " + valueOf(formData, "1_Full_Name"),
        "📱 மொபைல்: " + valueOf(formData, "2_Mobile"),
        "✉ மின்னஞ்சல்: " + (valueOf(formData, "3_Email") || "-"),
        "📍 முகவரி: " + valueOf(formData, "4_Address"),
        "🔁 முன்னாள் வாடிக்கையாளர்: " + existing,
        "🔢 கடன் கணக்கு எண்: " + (valueOf(formData, "14_Loan_Account_Number") || "-"),
        "📋 கடன் வகை: " + valueOf(formData, "5_Loan_Type"),
        "💰 தேவையான கடன் தொகை: ₹" + valueOf(formData, "6_Loan_Amount"),
        "💵 மாத வருமானம்: ₹" + valueOf(formData, "7_Monthly_Income"),
        "💼 வேலை: " + valueOf(formData, "8_Job_Type"),
        "🏢 நிறுவனம் / தொழில்: " + (valueOf(formData, "9_Company") || "-"),
        "📍 நகரம்: " + valueOf(formData, "10_City"),
        "📝 குறிப்பு: " + (valueOf(formData, "11_Notes") || "-")
      ].join("\n");
    }

    loanForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      if (!loanForm.checkValidity()) {
        loanForm.reportValidity();
        return;
      }

      const formData = new FormData(loanForm);
      const message = buildEnquiry(formData);

      // Save a minimal customer enquiry record first. RLS allows public INSERT only;
      // customer records are readable only by authorized admins.
      try {
        const sb = window.ABHINAV_SUPABASE;
        if (!sb || !sb.url || !sb.publishableKey) throw new Error("Customer enquiry service is not configured.");
        const existing = valueOf(formData, "13_Existing_Customer") || "-";
        const loanAccount = valueOf(formData, "14_Loan_Account_Number");
        const address = valueOf(formData, "4_Address");
        const saveResponse = await fetch(sb.url + "/rest/v1/customer_leads", {
          method: "POST",
          cache: "no-store",
          headers: {
            apikey: sb.publishableKey,
            "Content-Type": "application/json",
            Prefer: "return=minimal"
          },
          body: JSON.stringify({
            full_name: valueOf(formData, "1_Full_Name"),
            mobile: valueOf(formData, "2_Mobile"),
            existing_customer: existing,
            loan_account_number: loanAccount || null,
            address: address
          })
        });
        if (!saveResponse.ok) {
          const raw = await saveResponse.text();
          throw new Error(raw || "Unable to save enquiry.");
        }
      } catch (saveError) {
        if (status) {
          status.style.background = "#fff3f3";
          status.style.color = "#b42318";
          status.style.border = "1px solid #f1b8b8";
          status.textContent = "விண்ணப்பத்தை சேமிக்க முடியவில்லை. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.";
          status.style.display = "block";
        }
        if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = "விண்ணப்பத்தை சமர்ப்பிக்கவும் →"; }
        return;
      }

      const encoded = encodeURIComponent(message);
      const waUrl = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encoded;

      const subject = encodeURIComponent("New Loan Enquiry - Abhinav Bankers");
      const body = encodeURIComponent(message.replace(/\*/g, ""));
      const emailUrl = "mailto:abhinavbankers@gmail.com?subject=" + subject + "&body=" + body;

      if (status) {
        status.style.background = "#e7f6ec";
        status.style.color = "#1e7e34";
        status.style.border = "1px solid #b6e6c4";
        status.textContent = "WhatsApp மற்றும் Email அனுப்பும் options திறக்கப்படுகின்றன. இரண்டிலும் Send என்பதை அழுத்தி அனுப்பவும்.";
        status.style.display = "block";
      }

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "WhatsApp + Email திறக்கப்படுகிறது...";
      }

      // One button: open WhatsApp in a new tab and launch the device's email app.
      const waWindow = window.open(waUrl, "_blank", "noopener,noreferrer");
      setTimeout(function () {
        try {
          window.location.href = emailUrl;
        } catch (_) {
          if (!waWindow) window.open(waUrl, "_blank");
        }
      }, 250);

      setTimeout(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "விண்ணப்பத்தை சமர்ப்பிக்கவும் →";
        }
      }, 2200);
    });
  }

  /* ----- Smooth magnetic hover on primary CTAs (desktop) ----- */
  if (!reduced && window.matchMedia("(pointer: fine)").matches) {
    document.querySelectorAll(".btn:not(.btn-full)").forEach((btn) => {
      btn.addEventListener("mousemove", (e) => {
        const r = btn.getBoundingClientRect();
        const x = e.clientX - r.left - r.width / 2;
        const y = e.clientY - r.top - r.height / 2;
        btn.style.transform = `translate(${x * 0.08}px, ${y * 0.12 - 2}px)`;
      });
      btn.addEventListener("mouseleave", () => {
        btn.style.transform = "";
      });
    });
  }
})();
