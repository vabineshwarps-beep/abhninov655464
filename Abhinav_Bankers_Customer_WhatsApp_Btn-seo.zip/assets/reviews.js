/* Customer reviews: loads approved reviews from Supabase and submits new ones for moderation.
   Uses only the publishable key. RLS allows public INSERT (pending only) and public SELECT (approved only). */
(function () {
  "use strict";
  var sb = window.ABHINAV_SUPABASE;
  var listEl = document.getElementById("rv-list");
  var countEl = document.getElementById("rv-count");
  var moreBtn = document.getElementById("rv-more");
  var form = document.getElementById("rv-form");
  var msgEl = document.getElementById("rv-form-msg");
  var PAGE = (listEl && parseInt(listEl.getAttribute("data-limit"), 10)) || 20, offset = 0, total = null;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function headers(extra) {
    var h = { apikey: sb.publishableKey, Accept: "application/json" };
    for (var k in (extra || {})) h[k] = extra[k];
    return h;
  }
  function stars(n) {
    n = Math.max(1, Math.min(5, Number(n) || 0));
    var s = el("span", "rv-stars", "★★★★★".slice(0, n) + "☆☆☆☆☆".slice(0, 5 - n));
    s.setAttribute("role", "img");
    s.setAttribute("aria-label", n + " out of 5 stars");
    return s;
  }
  function fmtDate(iso) {
    try { return new Date(iso).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" }); }
    catch (e) { return ""; }
  }
  function card(r) {
    var c = el("article", "rv-card");
    var head = el("div", "rv-head");
    var who = el("div");
    who.appendChild(el("span", "rv-name", r.reviewer_name));
    if (r.area) who.appendChild(el("span", "rv-area", " · " + r.area));
    head.appendChild(who);
    head.appendChild(stars(r.rating));
    c.appendChild(head);
    c.appendChild(el("p", "rv-text", r.review_text));
    c.appendChild(el("div", "rv-date", fmtDate(r.created_at)));
    return c;
  }
  function setCount() {
    if (!countEl) return;
    countEl.textContent = total ? total + " customer review" + (total === 1 ? "" : "s") : "";
  }

  async function load() {
    if (!listEl) return;
    if (!sb || !sb.url || !sb.publishableKey) {
      listEl.replaceChildren(el("div", "rv-empty", "Reviews are temporarily unavailable."));
      return;
    }
    try {
      var url = sb.url + "/rest/v1/customer_reviews?select=id,reviewer_name,area,rating,review_text,created_at" +
        "&status=eq.approved&order=created_at.desc&limit=" + PAGE + "&offset=" + offset;
      var res = await fetch(url, { cache: "no-store", headers: headers({ Prefer: "count=exact" }) });
      if (!res.ok) throw new Error("load failed");
      var range = res.headers.get("Content-Range");
      if (range && range.indexOf("/") > -1) {
        var t = parseInt(range.split("/")[1], 10);
        if (!isNaN(t)) total = t;
      }
      var rows = await res.json();
      if (offset === 0) listEl.replaceChildren();
      if (offset === 0 && !rows.length && listEl.hasAttribute("data-hide-empty")) {
        var sec = listEl.closest("section"); if (sec) sec.hidden = true; return;
      }
      if (offset === 0 && !rows.length) {
        listEl.appendChild(el("div", "rv-empty", "No reviews yet. Be the first to share your experience below."));
      }
      rows.forEach(function (r) { listEl.appendChild(card(r)); });
      offset += rows.length;
      setCount();
      if (moreBtn) moreBtn.hidden = !(total != null && offset < total);
    } catch (e) {
      if (offset === 0 && listEl.hasAttribute("data-hide-empty")) { var s2 = listEl.closest("section"); if (s2) s2.hidden = true; return; }
      if (offset === 0) listEl.replaceChildren(el("div", "rv-empty", "Reviews could not be loaded right now. Please try again later."));
    }
  }
  if (moreBtn) moreBtn.addEventListener("click", load);

  function say(text, ok) {
    if (!msgEl) return;
    msgEl.className = "rv-msg " + (ok ? "ok" : "err");
    msgEl.textContent = text;
    msgEl.hidden = false;
  }

  if (form) {
    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var fd = new FormData(form);
      if (String(fd.get("website") || "").trim() !== "") { say("Thank you! Your review will appear after approval.", true); form.reset(); return; }
      try { if (Date.now() - Number(sessionStorage.getItem("rv_last") || 0) < 60000) { say("Please wait a minute before submitting another review.", false); return; } } catch (x) {}
      if (!sb || !sb.url || !sb.publishableKey) { say("Review service is not configured.", false); return; }
      var btn = document.getElementById("rv-submit");
      if (btn) btn.disabled = true;
      try {
        var res = await fetch(sb.url + "/rest/v1/customer_reviews", {
          method: "POST",
          cache: "no-store",
          headers: headers({ "Content-Type": "application/json", Prefer: "return=minimal" }),
          body: JSON.stringify({
            reviewer_name: String(fd.get("reviewer_name") || "").trim(),
            area: String(fd.get("area") || "").trim() || null,
            rating: parseInt(fd.get("rating"), 10),
            review_text: String(fd.get("review_text") || "").trim()
          })
        });
        if (!res.ok) throw new Error("save failed");
        try { sessionStorage.setItem("rv_last", String(Date.now())); } catch (x) {}
        form.reset();
        say("Thank you! Your review has been received and will appear after our team approves it.", true);
      } catch (err) {
        say("Sorry, your review could not be submitted. Please check the details (no links, 20+ characters) and try again.", false);
      } finally {
        if (btn) btn.disabled = false;
      }
    });
  }
  load();
})();
