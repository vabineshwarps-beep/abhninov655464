(function () {
  "use strict";

  const cfg = window.ABHINAV_SUPABASE;
  const msg = document.getElementById("msg");
  const loginBox = document.getElementById("login");
  const panel = document.getElementById("panel");
  const logoutBtn = document.getElementById("logout");
  const loginBtn = document.getElementById("loginBtn");
  const saveBtn = document.getElementById("saveBtn");

  let accessToken = null;
  let userId = null;

  function say(text, ok) {
    if (!msg) return;
    msg.textContent = text;
    msg.className = "msg " + (ok ? "ok" : "error");
  }

  function requireConfig() {
    if (!cfg || !cfg.url || !cfg.publishableKey) {
      throw new Error("Supabase configuration did not load. Upload assets/supabase-config.js and hard-refresh this page.");
    }
  }

  async function api(path, options) {
    requireConfig();
    const opts = options || {};
    const headers = Object.assign({
      apikey: cfg.publishableKey,
      Accept: "application/json",
    }, opts.headers || {});
    if (accessToken) headers.Authorization = "Bearer " + accessToken;
    if (opts.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";

    const response = await fetch(cfg.url + path, Object.assign({}, opts, {
      headers,
      cache: "no-store",
    }));
    const raw = await response.text();
    let data = null;
    try { data = raw ? JSON.parse(raw) : null; } catch (_) { data = raw; }
    if (!response.ok) {
      const detail = data && (data.msg || data.message || data.error_description || data.error);
      throw new Error(detail || ("Request failed (HTTP " + response.status + ")"));
    }
    return data;
  }

  function showPanel() {
    loginBox.classList.add("hidden");
    panel.classList.remove("hidden");
    logoutBtn.classList.remove("hidden");
  }

  function showLogin() {
    loginBox.classList.remove("hidden");
    panel.classList.add("hidden");
    logoutBtn.classList.add("hidden");
  }

  async function loadSettings() {
    const rows = await api("/rest/v1/site_settings?id=eq.1&select=gold_rate_22k,interest_rate,rate_date,season_offer,updated_at");
    if (!Array.isArray(rows) || !rows[0]) throw new Error("Site settings row not found.");
    const x = rows[0];
    document.getElementById("gold").value = x.gold_rate_22k;
    document.getElementById("interest").value = x.interest_rate;
    document.getElementById("date").value = x.rate_date;
    document.getElementById("offer").value = x.season_offer || "";
    document.getElementById("last").textContent = x.updated_at ? "Last updated: " + x.updated_at : "";
  }

  async function loginUser() {
    try {
      requireConfig();
      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value;
      if (!email || !password) throw new Error("Email and password are required.");
      loginBtn.disabled = true;
      say("Logging in…", true);

      const session = await api("/auth/v1/token?grant_type=password", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      if (!session || !session.access_token || !session.user || !session.user.id) {
        throw new Error("Supabase did not return a valid login session.");
      }
      accessToken = session.access_token;
      userId = session.user.id;

      const admins = await api("/rest/v1/admin_users?select=user_id&user_id=eq." + encodeURIComponent(userId));
      if (!Array.isArray(admins) || admins.length !== 1) {
        accessToken = null; userId = null;
        throw new Error("Login succeeded, but this account is not authorized as an admin.");
      }

      sessionStorage.setItem("abhinav_admin_session", JSON.stringify({ accessToken, userId }));
      showPanel();
      await loadSettings();
      say("Logged in securely.", true);
      document.getElementById("password").value = "";
    } catch (e) {
      say(e && e.message ? e.message : "Login failed.", false);
    } finally {
      loginBtn.disabled = false;
    }
  }

  async function save() {
    try {
      if (!accessToken) throw new Error("Please log in again.");
      const gold = Number(document.getElementById("gold").value);
      const interest = Number(document.getElementById("interest").value);
      const date = document.getElementById("date").value;
      const offer = document.getElementById("offer").value.trim();
      if (!(gold > 0 && gold < 1000000)) throw new Error("Gold rate is invalid.");
      if (!(interest >= 0 && interest < 100000)) throw new Error("Interest rate is invalid.");
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Rate date is required.");

      saveBtn.disabled = true;
      say("Saving…", true);
      await api("/rest/v1/site_settings?id=eq.1", {
        method: "PATCH",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({ gold_rate_22k: gold, interest_rate: interest, rate_date: date, season_offer: offer }),
      });
      await loadSettings();
      say("Saved successfully. Public pages will use the latest values.", true);
    } catch (e) {
      say(e && e.message ? e.message : "Save failed.", false);
    } finally {
      saveBtn.disabled = false;
    }
  }

  function logout() {
    accessToken = null;
    userId = null;
    sessionStorage.removeItem("abhinav_admin_session");
    showLogin();
    say("Logged out.", true);
  }

  async function restoreSession() {
    try {
      requireConfig();
      const saved = JSON.parse(sessionStorage.getItem("abhinav_admin_session") || "null");
      if (!saved || !saved.accessToken || !saved.userId) return;
      accessToken = saved.accessToken;
      userId = saved.userId;
      const admins = await api("/rest/v1/admin_users?select=user_id&user_id=eq." + encodeURIComponent(userId));
      if (!Array.isArray(admins) || admins.length !== 1) throw new Error("Not authorized");
      showPanel();
      await loadSettings();
      say("Session restored.", true);
    } catch (_) {
      accessToken = null;
      userId = null;
      sessionStorage.removeItem("abhinav_admin_session");
      showLogin();
    }
  }

  function init() {
    showLogin();
    loginBtn.addEventListener("click", loginUser);
    saveBtn.addEventListener("click", save);
    logoutBtn.addEventListener("click", logout);
    restoreSession();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
