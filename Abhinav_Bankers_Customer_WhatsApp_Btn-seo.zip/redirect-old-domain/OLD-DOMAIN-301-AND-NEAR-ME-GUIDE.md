# abhinavcapital.in → abhinavloanassociates.in (301) + local ranking steps

## Mukkiyam: yaar-kitta access irukku?
301 redirect old domain-oda **registrar / DNS / hosting** la dha set pannanum. Adhu yaaru account-la irukko avanga dha pannanum. Previous developer-kitta irundha, domain-oda login illana auth code / transfer kelunga. Access illama yaarum redirect set panna mudiyadhu.

## Option A – Registrar forwarding (hosting venam, easiest)
Domain register panna site (GoDaddy, BigRock, Namecheap, etc.) login → abhinavcapital.in → **Domain Forwarding / Redirect**:
- Forward to: `https://abhinavloanassociates.in`
- Type: **Permanent (301)** (Temporary / 302 select pannadheenga)
- **Forward only**, "masking / cloaking" venam
- `www.abhinavcapital.in`-kum same rule

## Option B – Old hosting irundha (cPanel / Hostinger etc.)
`htaccess.txt` file-a `.htaccess`-nu rename pannitu, abhinavcapital.in-oda `public_html` root-la upload pannunga. (Same folder-la already `.htaccess` irundha, adhoda content-ku mela idha paste pannunga.)
Old URLs-la same name irukkura pages (about, services, gold-loan, privacy, contact) one-to-one-ah pogum, matha ellam homepage-ku.

## Option C – Cloudflare irundha
Rules → Redirect Rules → Create:
- If Hostname equals `abhinavcapital.in` OR `www.abhinavcapital.in`
- Then Static redirect → `https://abhinavloanassociates.in/`, status **301**
- DNS-la rendu records-um orange cloud (proxied) irukkanum.

## Test
`http://`, `https://`, `www` – moonu versions-um `https://abhinavloanassociates.in/`-ku pogudha paarunga. httpstatus.io-la **301** nu varanum (302 illa).

## Google Search Console (idhu dha ranking transfer-ku help pannum)
1. abhinavloanassociates.in-ah Search Console-la add pannunga (Domain property, DNS TXT verify).
2. abhinavcapital.in-um add pannunga (verify pannanum, so old domain access venum).
3. Old property-la **Settings → Change of address** → new domain select.
4. Sitemap submit: `https://abhinavloanassociates.in/sitemap.xml`
5. URL Inspection-la ivanga-ku "Request indexing": homepage, `gold-loan-thanjavur.html`, `gold-loan-papanasam.html`, `gold-loan-ganapathi-agraharam.html`.

## Redirect-a eppo varaikum vachirukkanum
Minimum 1 year. Old domain renew pannitae irunga – expire aana ranking transfer poidum. Redirect live aagura varaikum old site-a delete pannadheenga.

## "gold loan near me" – GBP dha mukkiya lever
"Near me" results searcher-oda location, Google Business Profile, reviews-a base panni varum. Website mattum podhadhu.
- GBP verify pannirukkanum. Name, address, phone website-la irukkura madhiri **exact-ah** same (2/11, North Street, Ganapathi Agraharam, 614202).
- Website link: `https://abhinavloanassociates.in/`
- Hours: Mon–Sat 9:00–5:00, Sunday closed (site-la irukkura madhiri).
- Categories: GBP dashboard-la "Pawn shop" try pannunga, secondary-ah loan-related category add pannunga (available categories GBP-la check pannikonga).
- Photos: shop front, board, inside (real photos).
- Real customers-kita reviews kelunga. Review-ku gift/discount kudukka koodadhu, fake reviews Google ban pannum.
- Review-ku reply pannunga, month-ku oru post podunga.

## Realistic expectations
- New pages index aaga konja naal / weeks aagum. Search Console-la request indexing pannina fast-ah aagum.
- "gold loan thanjavur" madhiri searches-la Muthoot, Manappuram madhiri periya brands irukkum; "papanasam", "ganapathi agraharam" madhiri local searches-la easy-ah vara chance adhigam.
- Rank guarantee yaarum kudukka mudiyadhu. Adhu Google decide pannum.
